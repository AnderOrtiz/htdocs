let hide = document.getElementById('boton1');
let paf = document.getElementById('parrafo');

let isHiden = 0;
// isHiden lo utilizaremos para el switch

const hideParrafo = () => {
    switch (isHiden) {
        case 0:
            //caso 0, isHiden 0 desaparece el parrafo
            paf.style.display = 'none';
            isHiden = 1;
            break;
        case 1:
            //caso 1, isHiden 1 aparece el parrafo
            paf.style.display = 'block';
            isHiden = 0;
            break;
    }
}