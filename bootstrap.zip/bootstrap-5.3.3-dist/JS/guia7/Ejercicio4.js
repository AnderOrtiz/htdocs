document.getElementById("form").addEventListener("submit", function(event) {
    event.preventDefault(); // Evitar el envío del formulario para validar primero
    validateForm();
});

const validateForm = () => {
    var nameInput = document.getElementById("input").value;
    var messageElement = document.getElementById("message");

    if (nameInput.length < 5) {
        messageElement.style.color = "red";
        messageElement.textContent = "El nombre debe tener al menos 5 caracteres.";
    } else {
        messageElement.style.color = "green";
        messageElement.textContent = "¡Bienvenido, " + nameInput + "!";
    }
}
