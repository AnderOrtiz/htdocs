let b1 = document.getElementById('boton1');
let paf = document.getElementById('parrafo');
let tr1 = document.getElementById('tableTr1');

let colorEstado = 0;
// colorEstado lo utilizaremos para el switch

const cambiarColorParrafo = () => {
    switch (colorEstado) {
        case 0:
            //caso 0, colorEstado 0 cambia el color a red
            paf.style.backgroundColor = 'red';
            paf.style.color = 'white';
            tr1.style.backgroundColor = 'red';
            colorEstado = 1;
            break;
        case 1:
            //caso 1, colorEstado 1 cambia el color a white
            // Color original
            paf.style.backgroundColor = 'white';
            paf.style.color = 'black';
            tr1.style.backgroundColor = 'white';
            colorEstado = 0;
            break;
    }
}