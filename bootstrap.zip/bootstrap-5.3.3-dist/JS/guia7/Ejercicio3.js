const div = document.getElementById('contenedor')
//const contenido = document.getElementById('contenido')
const boton = document.getElementById('boton')


const crearElemento = () => {
    let pItem = document.createElement("p");
    pItem.textContent = "Elemento creado dinámicamente";
    contenedor.appendChild(pItem);
}
