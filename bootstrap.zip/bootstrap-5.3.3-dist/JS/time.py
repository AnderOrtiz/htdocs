
def timeConversion(s):
    # Write your code here    
    if s[-2:] == 'AM' and s[:2] == '12':
        resultado = '00' + s[2:-2]
        
    elif s[-2:] == 'PM' and s[:2] == '12':
        hours = s[:2] = '12'
        resultado = hours + s[2:-2]
        
    elif s[-2:] == 'AM':
        resultado = s[:-2]

    else:
        print(s[:-2])
        hours = s[:2]
        hours = int(hours) + 12
        resultado = str(hours) + s[2:-2]
    return resultado

timeConversion('12:00:01AM')