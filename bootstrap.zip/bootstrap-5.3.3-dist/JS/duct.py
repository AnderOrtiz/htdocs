square = {n:n**2 for n in range(1,11)}
print(square)